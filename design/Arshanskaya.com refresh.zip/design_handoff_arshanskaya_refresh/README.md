# Handoff: arshanskaya.com Refresh — Homepage & Paintings Index

## Overview
A refresh of the artist portfolio **arshanskaya.com** (Alexandra Arshanskaya — painter & performance artist, The Hague). The current site is a dated WordPress blog theme where the artwork is buried under a reverse-chronological feed of event announcements. This refresh moves it to a **gallery-first portfolio**, organized **by medium** (Paintings / Drawings / Performance / Space).

This bundle covers the two screens designed so far:
1. **Homepage** — direction "2b" (split hero), the approved direction.
2. **Paintings index** — the medium landing/gallery page.

The site will be **migrated to Astro**. Audience is **collectors/buyers and the general art public**. Language: **English only**. The aesthetic is intentionally **calm and static — no motion/animation** beyond a subtle link hover.

## About the Design Files
The files in this bundle are **design references created in HTML** — prototypes showing the intended look and layout, **not production code to copy directly**. They are authored as "Design Components" (`.dc.html`) which depend on a runtime (`support.js`); that runtime is a prototyping harness and is **not** part of the target stack.

Your task: **recreate these designs in Astro** (the chosen target), using standard Astro components + plain CSS (or the team's preferred styling approach). Treat the HTML/inline styles as the source of truth for layout, spacing, type, and color — but structure the implementation idiomatically (components, a shared layout, a small token file). Do **not** ship the `.dc.html` files or `support.js`.

## Fidelity
**High-fidelity.** Colors, typography, spacing, and layout are final and should be recreated faithfully. The only deliberately unfinished elements are **image placeholders** (striped fills labeled `[ … ]`) where the client has not yet supplied high-res scans — implement these as empty/placeholder image slots.

## Screens / Views

### 1. Homepage (`Homepage.dc.html` → section id `2b`)
> Note: `Homepage.dc.html` contains several exploration variants side-by-side on a canvas (ids `1a/1b/1c`, `2a/2b`). **Only `2b` is approved — ignore the others.** Build the homepage from the `#2b` section.

- **Purpose:** First impression; establish who the artist is and route visitors into the four mediums.
- **Overall:** 1440px design width, centered. Background `#f5f3ee`, ink `#1b1a17`. Vertical stack: nav → hairline → split hero → medium grid → "currently on view" strip → footer.

**Nav (sticky candidate, not sticky in mock)**
- Layout: flex, space-between, `padding: 32px 72px`.
- Left: wordmark "ALEXANDRA ARSHANSKAYA" — 14px, `letter-spacing:.24em`, uppercase, weight 500.
- Right: links `Paintings · Drawings · Performance · Space · About · Contact` — flex `gap:32px`, 11px, `letter-spacing:.22em`, uppercase, color `#4a473f`.
- Below nav: 1px rule `#e4dfd6`, inset `margin:0 72px`.

**Split hero** (`display:grid; grid-template-columns:1fr 1fr; min-height:720px`)
- Left cell: vertically centered, `padding:0 72px`.
  - Eyebrow: "Painter · Performance · The Hague" — 11px, `letter-spacing:.24em`, uppercase, `#8b857a`, `margin-bottom:30px`.
  - Statement: font **Spectral**, weight 300, **40px**, `line-height:1.4`, color `#22201c`, `text-wrap:pretty`. Copy: *"Working between the seen and the sensed — where spatial perception, time and the line become a single act."*
  - Actions (`margin-top:44px`, flex `gap:28px`): primary "VIEW THE WORK" — 11px uppercase `letter-spacing:.2em`, `border:1px solid #1b1a17`, `padding:15px 32px`. Secondary "ABOUT" — same type, `border-bottom:1.5px solid #1b1a17`, `padding:15px 0`.
- Right cell: artwork, `object-fit:cover`, fills the cell. Caption pinned bottom-left: `background:rgba(245,243,238,.92); padding:16px 22px`, font Spectral 15px — *"Pixels" — oil on canvas, 100 × 100 cm.*

**Medium grid** (`grid-template-columns:1fr 1fr; gap:2px; background:#e4dfd6` — the 2px gap + bg creates hairline dividers)
- Four tiles, each `height:560px`, `position:relative`, image `object-fit:cover`.
- Each tile overlay: bottom gradient `linear-gradient(to top, rgba(0,0,0,.42), transparent 52%)`, flex space-between align-end, `padding:34px`. Label in white, **24px**, `letter-spacing:.14em`, uppercase. Index number top-right in `rgba(255,255,255,.7)`, 12px.
- Tiles in order: **Paintings** (01), **Drawings** (02), **Performance** (03), **Space** (04).
- **Drawings tile** is a placeholder: striped fill `repeating-linear-gradient(45deg,#cfc9bf 0 14px,#d8d3ca 14px 28px)`, monospace note top-left `[ drawing — ink on paper ]` (11px, `#8a8478`), label/index in dark ink (no gradient overlay).

**"Currently on view" strip** (`grid-template-columns:180px 1fr auto; padding:46px 72px; border-top:1px solid #e4dfd6`)
- Label: "CURRENTLY ON VIEW" 11px `.24em` uppercase `#8b857a`.
- Body: Spectral 19px — *"Close Encounter with a Syzygy" (italic) — group exhibition, Gallery O-68, Velp.*
- Right: link "ALL EXHIBITIONS" 11px uppercase, `border-bottom:1px solid #1b1a17`.

**Footer** (`padding:40px 72px; background:#1b1a17; color:#cbc6bc`, flex space-between, 12px `.12em`)
- Left: "© 2026 Alexandra Arshanskaya · The Hague". Right: Instagram · Contact · Newsletter.

### 2. Paintings index (`Paintings.dc.html`)
- **Purpose:** Browse all paintings; entry point to individual works.
- **Overall:** same 1440px shell, bg `#f5f3ee`, ink `#1b1a17`.

**Nav:** identical to homepage; wordmark links to homepage; "Paintings" is the **active** item (`color:#1b1a17; border-bottom:1px solid #1b1a17; padding-bottom:3px`).

**Page header** (`grid-template-columns:1fr auto; align-items:end; padding:80px 72px 40px`)
- Left: eyebrow "WORKS · OIL & ACRYLIC ON CANVAS" (11px `.24em` `#8b857a`); title "Paintings" — **Spectral 64px**, weight 400, `line-height:1`.
- Right: intro paragraph, Spectral 300, 18px, `max-width:380px`, right-aligned, `#3a362f`.

**Filter row** (`padding:0 72px 40px`, flex space-between)
- Chips: **All** active (`background:#1b1a17; color:#f5f3ee`), others (`Pixels`, `Vanishing Point`, `Intertwined Realities`) outlined (`border:1px solid #d8d2c8; color:#4a473f`). All chips 11px `.16em` uppercase, `padding:10px 20px`. In Astro these should filter the grid by series (currently static).
- Right: count "9 WORKS" 11px `.16em` `#8b857a`.

**Works grid** (`grid-template-columns:1fr 1fr 1fr; gap:2px; background:#e4dfd6`)
- Card: `background:#f5f3ee; padding:26px`. Image block `height:400px; object-fit:cover`. Below: title (Spectral 18px), then meta line 12px `#8b857a` — `medium · dimensions · year`.
- Populated works (real images): Pixels (100×100, 2025), Pixel 7.5 (50×50, 2025), Vanishing Point 1.0 (2021), Intertwined Realities (16 × 40×40, 2020), Vanishing Point — Cube (2021).
- Remaining 4 cards are placeholders (striped fill + `[ painting — image to add ]`, muted "Untitled" title).

**Footer:** same as homepage (`padding:56px 72px`).

## Interactions & Behavior
- **No animations.** Only hover: links/cards fade to `opacity:.62` (`a:hover`). Keep this restrained.
- **Navigation:** medium tiles → medium index pages (e.g. Paintings tile → Paintings index). Work cards → individual artwork page (not yet designed). Wordmark → homepage.
- **Filters** (Paintings): should filter the grid by series client-side or via query param; currently rendered static with "All" selected.
- **Responsive:** designed at 1440px desktop only. For implementation: fluid down to a max content width; nav collapses to a menu on mobile; medium grid `1fr 1fr` → single column; paintings grid `3 → 2 → 1` columns. Confirm breakpoints with the client — mobile not yet designed.

## State Management
Minimal. Static content site.
- Paintings index: active filter (series) state → filters the works array. Source works from CMS/content collection (Astro content collections recommended), each work = `{ title, medium, widthCm, heightCm, year, series, image, alt }`.
- "Currently on view" (homepage) and exhibitions should come from a content collection so the client can update without code.

## Design Tokens
Colors:
- `--bg`: `#f5f3ee` (warm off-white, page)
- `--bg-alt`: `#e7e3db` / `#ded9d0` (image wells)
- `--ink`: `#1b1a17` (primary text, footer bg)
- `--muted`: `#8b857a` (captions, eyebrows)
- `--muted-ink`: `#4a473f` (nav links)
- `--body-serif-ink`: `#22201c` / `#3a362f`
- `--rule`: `#e4dfd6` (hairlines); grid divider bg also `#e4dfd6`
- `--chip-border`: `#d8d2c8`
- `--footer-text`: `#cbc6bc`
- Placeholder stripes: `repeating-linear-gradient(45deg,#cfc9bf 0 14px,#d8d3ca 14px 28px)`
- Overlay gradient: `linear-gradient(to top, rgba(0,0,0,.42), transparent 52%)`

Typography:
- **Display / body serif:** Spectral (Google Fonts), weights 300/400, italics used for exhibition titles.
- **UI / labels:** Helvetica Neue / Helvetica / Arial (system stack). Uppercase, wide tracking for all labels/nav.
- Scale: hero statement 40px/1.4; page title 64px/1; section labels 24px; body 18–19px; eyebrows & nav & meta 11–12px.
- Letter-spacing: labels `.14em–.24em`; nav `.22em`; wordmark `.24em`.

Spacing:
- Page gutter: `72px`. Section vertical padding: `32–110px`. Card padding: `26px`. Grid hairline gap: `2px`.

No border-radius (everything square-cornered). No shadows in-page (mock uses shadow only to float the canvas frames — ignore).

## Assets
All imagery is currently **hotlinked from the existing WordPress site** for the mock. These must be **downloaded, re-exported at high resolution, and hosted in the new project** (do not hotlink in production):
- `https://arshanskaya.com/wp-content/uploads/2025/08/Pixels.jpg` — "Pixels" (hero + card)
- `https://arshanskaya.com/wp-content/uploads/2025/08/Pixel-7.5-wall.jpg` — "Pixel 7.5"
- `https://arshanskaya.com/wp-content/uploads/2021/09/IMG_7294.jpg` — "Vanishing Point 1.0"
- `https://arshanskaya.com/wp-content/uploads/2021/09/Intertwined-Realities-website.jpg` — "Intertwined Realities"
- `https://arshanskaya.com/wp-content/uploads/2021/06/Cube-at-Quartier-close-up.jpg` — "Vanishing Point — Cube"
- `https://arshanskaya.com/wp-content/uploads/2020/09/Me-Intertwined-Realities-1.jpg` — Performance tile (artist with work)
- `https://arshanskaya.com/wp-content/uploads/2022/02/moon-gallery-foundation-ISS-payload-square.jpg` — Space tile (Moon Gallery / ISS)

Still needed from client: high-res **drawing** scans (placeholder for now), and remaining paintings (4 placeholder cards).

Fonts: Spectral via Google Fonts (or self-host). No icon set is used.

## Files
- `Homepage.dc.html` — homepage; **build from the `#2b` section only** (other ids are rejected explorations).
- `Paintings.dc.html` — Paintings index page.
- `support.js` — prototyping runtime only; **not** for production, reference only.

## Not yet designed (roadmap)
Individual artwork (detail) page, About page, Drawings/Performance/Space index pages, Contact, mobile layouts.
